
  # Screenshot review request

  This is a code bundle for Screenshot review request. The original project is available at https://www.figma.com/design/mbVi4Vm49Tzb5vlr3xJ3GE/Screenshot-review-request.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  