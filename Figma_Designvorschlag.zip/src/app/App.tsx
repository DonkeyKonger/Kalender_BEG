import { useState } from 'react';
import DesignA_WarmOffice from './components/DesignA_WarmOffice';
import DesignB_ModernEnterprise from './components/DesignB_ModernEnterprise';
import DesignC_Industrial from './components/DesignC_Industrial';
import DesignOptimized from './components/DesignOptimized';

type DesignVariant = 'warm' | 'modern' | 'industrial' | 'optimized';

export default function App() {
  const [activeDesign, setActiveDesign] = useState<DesignVariant>('optimized');

  return (
    <div className="size-full flex flex-col">
      {/* Design Switcher */}
      <div className="bg-gray-900 text-white px-6 py-3 flex items-center justify-between border-b border-gray-700">
        <div className="flex items-center gap-4">
          <span className="text-sm font-semibold">Design Preview:</span>
          <div className="flex gap-2">
            <button
              onClick={() => setActiveDesign('optimized')}
              className={`px-3 py-1.5 text-sm font-medium transition-colors ${
                activeDesign === 'optimized'
                  ? 'bg-[#3b82f6] text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              ✓ Optimiert
            </button>
            <div className="w-px bg-gray-700"></div>
            <button
              onClick={() => setActiveDesign('warm')}
              className={`px-3 py-1.5 text-sm font-medium transition-colors ${
                activeDesign === 'warm'
                  ? 'bg-[#c17a3a] text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              A) Warm Office
            </button>
            <button
              onClick={() => setActiveDesign('modern')}
              className={`px-3 py-1.5 text-sm font-medium transition-colors ${
                activeDesign === 'modern'
                  ? 'bg-[#212529] text-white border border-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              B) Modern Enterprise
            </button>
            <button
              onClick={() => setActiveDesign('industrial')}
              className={`px-3 py-1.5 text-sm font-medium transition-colors ${
                activeDesign === 'industrial'
                  ? 'bg-[#f59e0b] text-gray-900'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              C) Industrial
            </button>
          </div>
        </div>
        <div className="text-xs text-gray-400">
          {activeDesign === 'optimized' && 'Optimierte professionelle Desktop-Ansicht mit Info-Sidebar'}
          {activeDesign === 'warm' && 'Warm technical office style with beige/tan backgrounds'}
          {activeDesign === 'modern' && 'Modern neutral enterprise style with cool grays'}
          {activeDesign === 'industrial' && 'Industrial construction software with dark theme'}
        </div>
      </div>

      {/* Active Design */}
      <div className="flex-1 overflow-hidden">
        {activeDesign === 'optimized' && <DesignOptimized />}
        {activeDesign === 'warm' && <DesignA_WarmOffice />}
        {activeDesign === 'modern' && <DesignB_ModernEnterprise />}
        {activeDesign === 'industrial' && <DesignC_Industrial />}
      </div>
    </div>
  );
}