import { ChevronLeft, MoreVertical, Download, Filter } from 'lucide-react';

export default function DesignB_ModernEnterprise() {
  return (
    <div className="size-full bg-[#f8f9fa] overflow-auto">
      <div className="max-w-[1800px] mx-auto p-6">
        {/* Breadcrumb */}
        <button className="flex items-center gap-1.5 text-sm text-[#6c757d] hover:text-[#212529] mb-4 -ml-1">
          <ChevronLeft size={16} />
          Baustellen
        </button>

        {/* Project Header */}
        <div className="bg-white border border-[#dee2e6] mb-4">
          <div className="px-6 py-4 border-b border-[#dee2e6]">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[10px] font-semibold text-[#6c757d] uppercase tracking-wider mb-1">
                  Projektakte
                </div>
                <h1 className="text-xl font-semibold text-[#212529] mb-0.5">Schlüchtermann Klinik</h1>
                <div className="text-sm text-[#6c757d]">8007 - ebm</div>
              </div>
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 bg-[#d1e7dd] text-[#0f5132] text-xs font-medium">
                  Aktiv
                </span>
                <button className="p-1.5 hover:bg-[#e9ecef] text-[#6c757d]">
                  <MoreVertical size={18} />
                </button>
              </div>
            </div>
          </div>

          {/* Main Tabs */}
          <div className="px-6 bg-[#f8f9fa]">
            <div className="flex gap-0 -mb-px">
              {['Übersicht', 'Ordnerstruktur', 'Montagezeiten', 'Aufmaß', 'Werkzeuge & Material'].map((tab, i) => (
                <button
                  key={tab}
                  className={`px-4 py-3 text-sm font-medium border-b-2 ${
                    i === 3
                      ? 'border-[#212529] text-[#212529] bg-white'
                      : 'border-transparent text-[#6c757d] hover:text-[#212529] hover:bg-[#e9ecef]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Content Card */}
        <div className="bg-white border border-[#dee2e6]">
          {/* Sub Tabs */}
          <div className="px-6 py-3 border-b border-[#dee2e6]">
            <div className="flex gap-2">
              {['Zeitenliste', 'Prüfung', 'Zeitauswertung'].map((tab, i) => (
                <button
                  key={tab}
                  className={`px-3 py-1.5 text-sm font-medium ${
                    i === 0
                      ? 'bg-[#212529] text-white'
                      : 'bg-[#e9ecef] text-[#495057] hover:bg-[#dee2e6]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Toolbar */}
          <div className="px-6 py-2 border-b border-[#dee2e6] bg-[#f8f9fa] flex items-center justify-between">
            <button className="px-3 py-1.5 text-sm text-[#495057] hover:bg-[#e9ecef] font-medium">
              Zurück
            </button>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 border-r border-[#dee2e6] pr-2 mr-1">
                <button className="px-2.5 py-1.5 text-xs text-[#495057] hover:bg-[#e9ecef] font-medium">
                  Liste
                </button>
                <button className="px-2.5 py-1.5 text-xs text-[#495057] hover:bg-[#e9ecef] font-medium">
                  Tabelle
                </button>
              </div>
              <button className="px-2.5 py-1.5 text-xs bg-[#fff3cd] text-[#664d03] hover:bg-[#ffecb5] font-medium">
                Noch offen
              </button>
              <button className="px-2.5 py-1.5 text-xs text-[#495057] hover:bg-[#e9ecef] font-medium">
                Undo
              </button>
              <button className="px-2.5 py-1.5 text-xs text-[#495057] hover:bg-[#e9ecef] font-medium">
                Auf Monteurstand zurücksetzen
              </button>
              <div className="w-px h-4 bg-[#dee2e6] mx-1"></div>
              <button className="p-1.5 hover:bg-[#e9ecef] text-[#6c757d]">
                <Filter size={14} />
              </button>
              <button className="p-1.5 hover:bg-[#e9ecef] text-[#6c757d]">
                <Download size={14} />
              </button>
              <button className="px-3 py-1.5 text-xs bg-[#212529] text-white hover:bg-[#000] font-medium ml-1">
                Als abgerechnet markieren
              </button>
            </div>
          </div>

          {/* Table Header */}
          <div className="px-6 py-2.5 border-b border-[#dee2e6] bg-[#f8f9fa]">
            <h2 className="text-sm font-semibold text-[#212529]">Aufmaß 8007.05</h2>
          </div>

          {/* Excel-Style Table */}
          <div className="overflow-auto" style={{ maxHeight: 'calc(100vh - 400px)' }}>
            <table className="border-collapse" style={{ fontVariantNumeric: 'tabular-nums' }}>
              <thead className="sticky top-0 z-10">
                {/* Header Row 1: Position Numbers */}
                <tr>
                  <th className="bg-[#e9ecef] border border-[#adb5bd] text-[10px] font-semibold text-[#495057] text-left px-2 py-1 min-w-[100px] sticky left-0 z-20">
                    Pos.-Nr.
                  </th>
                  <th className="bg-[#e9ecef] border border-[#adb5bd] text-[10px] font-semibold text-[#495057] text-left px-2 py-1 min-w-[200px] sticky left-[100px] z-20">
                    Beschreibung
                  </th>
                  <th className="bg-[#e9ecef] border border-[#adb5bd] text-[10px] font-semibold text-[#495057] text-left px-2 py-1 w-[60px] sticky left-[300px] z-20">
                    Einheit
                  </th>
                  <th className="bg-[#e9ecef] border border-[#adb5bd] text-[10px] font-semibold text-[#495057] text-left px-2 py-1 min-w-[160px] sticky left-[360px] z-20">
                    Bauteil / Ort
                  </th>
                  {['1.01.05.20', '1.01.05.120', '1.01.05.160', '1.01.05.220', '1.01.05.280', '1.01.05.310', '1.01.05.450'].map(col => (
                    <th key={col} className="bg-[#e9ecef] border border-[#adb5bd] text-[10px] font-semibold text-[#495057] text-center px-1.5 py-1 w-[85px]">
                      {col}
                    </th>
                  ))}
                </tr>
                {/* Header Row 2: Article Descriptions */}
                <tr>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] sticky left-0 z-20"></td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] sticky left-[100px] z-20"></td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] sticky left-[300px] z-20"></td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] sticky left-[360px] z-20"></td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] text-[9px] text-[#6c757d] text-center px-1 py-0.5 leading-tight">
                    FS L060...V5<br />Snegleiter<br />300/60 mm
                  </td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] text-[9px] text-[#6c757d] text-center px-1 py-0.5 leading-tight">
                    vorgenahte<br />C-Profitschiene<br />nach Örtlichkeit
                  </td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] text-[9px] text-[#6c757d] text-center px-1 py-0.5 leading-tight">
                    90°Rinnenbogen<br />600/60 mm<br />EF
                  </td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] text-[9px] text-[#6c757d] text-center px-1 py-0.5 leading-tight">
                    Vertikalgelenk<br />600/60 mm<br />als Bogen
                  </td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] text-[9px] text-[#6c757d] text-center px-1 py-0.5 leading-tight">
                    UEB-Stiel<br />bis 600 mm<br />liefern
                  </td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] text-[9px] text-[#6c757d] text-center px-1 py-0.5 leading-tight">
                    UEB-Stiel<br />bis 600 mm<br />montieren
                  </td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] text-[9px] text-[#6c757d] text-center px-1 py-0.5 leading-tight">
                    Stelzausleger<br />200 mm<br />liefern
                  </td>
                </tr>
                {/* Header Row 3: Units */}
                <tr>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] sticky left-0 z-20"></td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] sticky left-[100px] z-20"></td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] sticky left-[300px] z-20"></td>
                  <td className="bg-[#f8f9fa] border border-[#adb5bd] sticky left-[360px] z-20"></td>
                  {Array(7).fill('STCK').map((unit, i) => (
                    <td key={i} className="bg-[#f8f9fa] border border-[#adb5bd] text-[10px] font-medium text-[#495057] text-center px-1.5 py-0.5">
                      {unit}
                    </td>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Data Row 1: EG */}
                <tr className="hover:bg-[#f8f9fa]">
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] px-2 py-1 sticky left-0 z-10">EG</td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[100px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[300px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[360px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] text-right px-2 py-1">30,00</td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] text-right px-2 py-1">5,00</td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] text-right px-2 py-1">5,00</td>
                </tr>
                {/* Data Row 2: 1. OG */}
                <tr className="hover:bg-[#f8f9fa]">
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] px-2 py-1 sticky left-0 z-10">1. OG</td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[100px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[300px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[360px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] text-right px-2 py-1">500,00</td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] text-right px-2 py-1">100,00</td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                </tr>
                {/* Data Row 3: UG, 1 Achse D - E */}
                <tr className="hover:bg-[#f8f9fa]">
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] px-2 py-1 sticky left-0 z-10">UG, 1 Achse D - E</td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[100px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[300px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[360px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] text-right px-2 py-1">1.000,00</td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                </tr>
                {/* Data Row 4: Dach */}
                <tr className="hover:bg-[#f8f9fa]">
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#6c757d] px-2 py-1 leading-tight sticky left-0 z-10">
                    Dach, schräge,<br />Sicht zum<br />Feuerwehrhaus
                  </td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[100px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[300px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] sticky left-[360px] z-10"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#dee2e6] text-[11px] text-[#212529] text-right px-2 py-1">1,60</td>
                </tr>
                {/* Additional empty rows for scrolling demonstration */}
                {Array(15).fill(null).map((_, idx) => (
                  <tr key={`empty-${idx}`} className="hover:bg-[#f8f9fa]">
                    <td className="bg-white border border-[#dee2e6] text-[11px] px-2 py-1 sticky left-0 z-10"></td>
                    <td className="bg-white border border-[#dee2e6] sticky left-[100px] z-10"></td>
                    <td className="bg-white border border-[#dee2e6] sticky left-[300px] z-10"></td>
                    <td className="bg-white border border-[#dee2e6] sticky left-[360px] z-10"></td>
                    {Array(7).fill(null).map((_, i) => (
                      <td key={i} className="bg-white border border-[#dee2e6] text-[11px] text-right px-2 py-1"></td>
                    ))}
                  </tr>
                ))}
                {/* Total Row */}
                <tr className="sticky bottom-0 z-10">
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] text-[11px] font-semibold text-[#212529] px-2 py-1 sticky left-0 z-20">
                    Gesamt
                  </td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] sticky left-[100px] z-20"></td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] sticky left-[300px] z-20"></td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] sticky left-[360px] z-20"></td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] text-[11px] font-semibold text-[#212529] text-right px-2 py-1">500,00</td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] text-[11px] font-semibold text-[#212529] text-right px-2 py-1">100,00</td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] text-[11px] font-semibold text-[#212529] text-right px-2 py-1">30,00</td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] text-[11px] font-semibold text-[#212529] text-right px-2 py-1">5,00</td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] text-[11px] font-semibold text-[#212529] text-right px-2 py-1">1.000,00</td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] text-[11px] font-semibold text-[#212529] text-right px-2 py-1">5,00</td>
                  <td className="bg-[#e9ecef] border-2 border-[#adb5bd] text-[11px] font-semibold text-[#212529] text-right px-2 py-1">1,60</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
