import { ChevronLeft, MoreVertical, Download, Filter, List, Table2, RotateCcw, FileCheck } from 'lucide-react';

export default function DesignOptimized() {
  return (
    <div className="size-full bg-[#f5f7fa] overflow-auto">
      <div className="h-full flex flex-col">
        {/* Breadcrumb */}
        <div className="px-6 py-2 bg-white border-b border-[#d1d9e6]">
          <button className="flex items-center gap-1.5 text-sm text-[#64748b] hover:text-[#334155]">
            <ChevronLeft size={16} />
            Baustellen
          </button>
        </div>

        {/* Project Header - Kompakter */}
        <div className="bg-white border-b border-[#d1d9e6]">
          <div className="px-6 py-3">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[10px] font-semibold text-[#64748b] uppercase tracking-wider mb-1">
                  Projektakte
                </div>
                <h1 className="text-lg font-semibold text-[#0f172a] mb-0.5">Schlüchtermann Klinik</h1>
                <div className="text-sm text-[#64748b]">8007 - ebm</div>
              </div>
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 bg-[#dcfce7] text-[#166534] text-xs font-medium">
                  Aktiv
                </span>
                <button className="p-1.5 hover:bg-[#f1f5f9] text-[#64748b] rounded">
                  <MoreVertical size={18} />
                </button>
              </div>
            </div>
          </div>

          {/* Main Tabs */}
          <div className="px-6 border-t border-[#e2e8f0]">
            <div className="flex gap-0 -mb-px">
              {['Übersicht', 'Ordnerstruktur', 'Montagezeiten', 'Aufmaß', 'Werkzeuge & Material'].map((tab, i) => (
                <button
                  key={tab}
                  className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                    i === 3
                      ? 'border-[#3b82f6] text-[#1e40af] bg-[#eff6ff]'
                      : 'border-transparent text-[#64748b] hover:text-[#334155] hover:bg-[#f8fafc]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {/* Main Content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Sub Navigation */}
            <div className="bg-white border-b border-[#d1d9e6]">
              <div className="px-6 py-2.5 flex items-center gap-2">
                {['Zeitenliste', 'Prüfung', 'Zeitauswertung'].map((tab, i) => (
                  <button
                    key={tab}
                    className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                      i === 0
                        ? 'bg-[#1e293b] text-white'
                        : 'bg-[#f1f5f9] text-[#475569] hover:bg-[#e2e8f0]'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* Package Header mit Status */}
            <div className="px-6 py-2.5 bg-[#f8fafc] border-b border-[#d1d9e6] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <h2 className="text-sm font-semibold text-[#0f172a]">Aufmaß 8007.05</h2>
                <span className="px-2 py-0.5 bg-[#fef3c7] text-[#92400e] text-xs font-medium rounded">
                  In Prüfung
                </span>
              </div>
              <div className="text-xs text-[#64748b]">
                Letzte Änderung: 27.05.2026, 14:32 Uhr
              </div>
            </div>

            {/* Toolbar - Gruppiert */}
            <div className="px-6 py-2 bg-white border-b border-[#d1d9e6]">
              <div className="flex items-center justify-between gap-4">
                {/* Links: Navigation */}
                <div className="flex items-center gap-3">
                  <button className="px-3 py-1.5 text-xs text-[#475569] hover:bg-[#f1f5f9] rounded font-medium">
                    Zurück
                  </button>

                  <div className="w-px h-4 bg-[#d1d9e6]"></div>

                  {/* Ansicht Toggle */}
                  <div className="flex items-center gap-1 bg-[#f8fafc] rounded p-0.5">
                    <button className="px-2 py-1 text-xs text-[#64748b] hover:bg-white hover:shadow-sm rounded flex items-center gap-1.5">
                      <List size={13} />
                      Liste
                    </button>
                    <button className="px-2 py-1 text-xs bg-white text-[#1e293b] shadow-sm rounded flex items-center gap-1.5 font-medium">
                      <Table2 size={13} />
                      Tabelle
                    </button>
                  </div>

                  <div className="w-px h-4 bg-[#d1d9e6]"></div>

                  {/* Status Filter */}
                  <div className="flex items-center gap-1">
                    <button className="px-2.5 py-1.5 text-xs text-[#64748b] hover:bg-[#f1f5f9] rounded font-medium">
                      Alle
                    </button>
                    <button className="px-2.5 py-1.5 text-xs bg-[#fef3c7] text-[#92400e] rounded font-medium">
                      Noch offen
                    </button>
                    <button className="px-2.5 py-1.5 text-xs text-[#64748b] hover:bg-[#f1f5f9] rounded font-medium">
                      Abgerechnet
                    </button>
                  </div>
                </div>

                {/* Rechts: Aktionen */}
                <div className="flex items-center gap-2">
                  <button className="px-2.5 py-1.5 text-xs text-[#64748b] hover:bg-[#f1f5f9] rounded flex items-center gap-1.5">
                    <RotateCcw size={13} />
                    Undo
                  </button>
                  <button className="px-2.5 py-1.5 text-xs text-[#64748b] hover:bg-[#f1f5f9] rounded font-medium">
                    Auf Monteurstand zurücksetzen
                  </button>

                  <div className="w-px h-4 bg-[#d1d9e6]"></div>

                  <button className="p-1.5 hover:bg-[#f1f5f9] text-[#64748b] rounded" title="Filter">
                    <Filter size={14} />
                  </button>
                  <button className="p-1.5 hover:bg-[#f1f5f9] text-[#64748b] rounded" title="Export">
                    <Download size={14} />
                  </button>

                  <div className="w-px h-4 bg-[#d1d9e6] mx-1"></div>

                  <button className="px-3 py-1.5 text-xs bg-[#1e293b] text-white hover:bg-[#0f172a] rounded font-medium flex items-center gap-1.5">
                    <FileCheck size={13} />
                    Als abgerechnet markieren
                  </button>
                </div>
              </div>
            </div>

            {/* Table Container */}
            <div className="flex-1 overflow-auto bg-white">
              <div className="h-full overflow-auto">
                <table className="border-collapse w-full" style={{ fontVariantNumeric: 'tabular-nums' }}>
                  <thead className="sticky top-0 z-10">
                    {/* Header Row 1: Position Numbers */}
                    <tr>
                      <th className="bg-[#f1f5f9] border border-[#cbd5e1] text-[10px] font-semibold text-[#475569] text-left px-2 py-1.5 min-w-[100px] sticky left-0 z-20">
                        Pos.-Nr.
                      </th>
                      <th className="bg-[#f1f5f9] border border-[#cbd5e1] text-[10px] font-semibold text-[#475569] text-left px-2 py-1.5 min-w-[200px] sticky left-[100px] z-20">
                        Beschreibung
                      </th>
                      <th className="bg-[#f1f5f9] border border-[#cbd5e1] text-[10px] font-semibold text-[#475569] text-left px-2 py-1.5 w-[60px] sticky left-[300px] z-20">
                        Einheit
                      </th>
                      <th className="bg-[#f1f5f9] border border-[#cbd5e1] text-[10px] font-semibold text-[#475569] text-left px-2 py-1.5 min-w-[160px] sticky left-[360px] z-20">
                        Bauteil / Ort
                      </th>
                      {['1.01.05.20', '1.01.05.120', '1.01.05.160', '1.01.05.220', '1.01.05.280', '1.01.05.310', '1.01.05.450'].map(col => (
                        <th key={col} className="bg-[#f1f5f9] border border-[#cbd5e1] text-[10px] font-semibold text-[#475569] text-center px-1.5 py-1.5 w-[85px]">
                          {col}
                        </th>
                      ))}
                    </tr>
                    {/* Header Row 2: Article Descriptions */}
                    <tr>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] sticky left-0 z-20"></td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] sticky left-[100px] z-20"></td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] sticky left-[300px] z-20"></td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] sticky left-[360px] z-20"></td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] text-[9px] text-[#64748b] text-center px-1 py-1 leading-tight">
                        FS L060...V5<br />Snegleiter<br />300/60 mm
                      </td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] text-[9px] text-[#64748b] text-center px-1 py-1 leading-tight">
                        vorgenahte<br />C-Profitschiene<br />nach Örtlichkeit
                      </td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] text-[9px] text-[#64748b] text-center px-1 py-1 leading-tight">
                        90°Rinnenbogen<br />600/60 mm<br />EF
                      </td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] text-[9px] text-[#64748b] text-center px-1 py-1 leading-tight">
                        Vertikalgelenk<br />600/60 mm<br />als Bogen
                      </td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] text-[9px] text-[#64748b] text-center px-1 py-1 leading-tight">
                        UEB-Stiel<br />bis 600 mm<br />liefern
                      </td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] text-[9px] text-[#64748b] text-center px-1 py-1 leading-tight">
                        UEB-Stiel<br />bis 600 mm<br />montieren
                      </td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] text-[9px] text-[#64748b] text-center px-1 py-1 leading-tight">
                        Stelzausleger<br />200 mm<br />liefern
                      </td>
                    </tr>
                    {/* Header Row 3: Units */}
                    <tr>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] sticky left-0 z-20"></td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] sticky left-[100px] z-20"></td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] sticky left-[300px] z-20"></td>
                      <td className="bg-[#f8fafc] border border-[#cbd5e1] sticky left-[360px] z-20"></td>
                      {Array(7).fill('STCK').map((unit, i) => (
                        <td key={i} className="bg-[#f8fafc] border border-[#cbd5e1] text-[10px] font-medium text-[#475569] text-center px-1.5 py-1">
                          {unit}
                        </td>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {/* Data Row 1: EG */}
                    <tr className="hover:bg-[#f8fafc]">
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] px-2 py-1.5 sticky left-0 z-10">EG</td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[100px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[300px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[360px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] text-right px-2 py-1.5">30,00</td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] text-right px-2 py-1.5">5,00</td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] text-right px-2 py-1.5">5,00</td>
                    </tr>
                    {/* Data Row 2: 1. OG */}
                    <tr className="hover:bg-[#f8fafc]">
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] px-2 py-1.5 sticky left-0 z-10">1. OG</td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[100px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[300px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[360px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] text-right px-2 py-1.5">500,00</td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] text-right px-2 py-1.5">100,00</td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                    </tr>
                    {/* Data Row 3: UG, 1 Achse D - E */}
                    <tr className="hover:bg-[#f8fafc]">
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] px-2 py-1.5 sticky left-0 z-10">UG, 1 Achse D - E</td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[100px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[300px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[360px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] text-right px-2 py-1.5">1.000,00</td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                    </tr>
                    {/* Data Row 4: Dach */}
                    <tr className="hover:bg-[#f8fafc]">
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#64748b] px-2 py-1.5 leading-tight sticky left-0 z-10">
                        Dach, schräge,<br />Sicht zum<br />Feuerwehrhaus
                      </td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[100px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[300px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] sticky left-[360px] z-10"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                      <td className="bg-white border border-[#e2e8f0] text-[11px] text-[#0f172a] text-right px-2 py-1.5">1,60</td>
                    </tr>
                    {/* Additional empty rows */}
                    {Array(20).fill(null).map((_, idx) => (
                      <tr key={`empty-${idx}`} className="hover:bg-[#f8fafc]">
                        <td className="bg-white border border-[#e2e8f0] text-[11px] px-2 py-1.5 sticky left-0 z-10"></td>
                        <td className="bg-white border border-[#e2e8f0] sticky left-[100px] z-10"></td>
                        <td className="bg-white border border-[#e2e8f0] sticky left-[300px] z-10"></td>
                        <td className="bg-white border border-[#e2e8f0] sticky left-[360px] z-10"></td>
                        {Array(7).fill(null).map((_, i) => (
                          <td key={i} className="bg-white border border-[#e2e8f0] text-[11px] text-right px-2 py-1.5"></td>
                        ))}
                      </tr>
                    ))}
                    {/* Total Row */}
                    <tr className="sticky bottom-0 z-10">
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] text-[11px] font-semibold text-[#0f172a] px-2 py-2 sticky left-0 z-20">
                        Gesamt
                      </td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] sticky left-[100px] z-20"></td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] sticky left-[300px] z-20"></td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] sticky left-[360px] z-20"></td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] text-[11px] font-semibold text-[#0f172a] text-right px-2 py-2">500,00</td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] text-[11px] font-semibold text-[#0f172a] text-right px-2 py-2">100,00</td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] text-[11px] font-semibold text-[#0f172a] text-right px-2 py-2">30,00</td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] text-[11px] font-semibold text-[#0f172a] text-right px-2 py-2">5,00</td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] text-[11px] font-semibold text-[#0f172a] text-right px-2 py-2">1.000,00</td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] text-[11px] font-semibold text-[#0f172a] text-right px-2 py-2">5,00</td>
                      <td className="bg-[#f1f5f9] border-2 border-[#94a3b8] text-[11px] font-semibold text-[#0f172a] text-right px-2 py-2">1,60</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right Sidebar - Info Panel */}
          <div className="w-80 bg-white border-l border-[#d1d9e6] flex flex-col">
            <div className="p-4 border-b border-[#e2e8f0]">
              <h3 className="text-sm font-semibold text-[#0f172a] mb-3">Paket-Information</h3>

              <div className="space-y-3">
                <div>
                  <div className="text-xs text-[#64748b] mb-1">Status</div>
                  <div className="px-2 py-1 bg-[#fef3c7] text-[#92400e] text-xs font-medium rounded inline-block">
                    In Prüfung
                  </div>
                </div>

                <div>
                  <div className="text-xs text-[#64748b] mb-1">Paket-Nr.</div>
                  <div className="text-sm text-[#0f172a]">8007.05</div>
                </div>

                <div>
                  <div className="text-xs text-[#64748b] mb-1">Erstellt am</div>
                  <div className="text-sm text-[#0f172a]">12.05.2026</div>
                </div>

                <div>
                  <div className="text-xs text-[#64748b] mb-1">Monteur</div>
                  <div className="text-sm text-[#0f172a]">M. Schmidt</div>
                </div>
              </div>
            </div>

            <div className="p-4 border-b border-[#e2e8f0]">
              <h3 className="text-sm font-semibold text-[#0f172a] mb-3">Summen</h3>

              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-[#64748b]">Positionen gesamt:</span>
                  <span className="text-[#0f172a] font-medium">7</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-[#64748b]">Positionen erfasst:</span>
                  <span className="text-[#0f172a] font-medium">7</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-[#64748b]">Bauteile:</span>
                  <span className="text-[#0f172a] font-medium">4</span>
                </div>

                <div className="pt-2 mt-2 border-t border-[#e2e8f0]">
                  <div className="flex justify-between text-xs">
                    <span className="text-[#64748b] font-medium">Gesamtstück:</span>
                    <span className="text-[#0f172a] font-semibold">1.641,60</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4">
              <h3 className="text-sm font-semibold text-[#0f172a] mb-3">Aktivitäten</h3>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="text-[#64748b]">27.05.2026, 14:32</div>
                  <div className="text-[#0f172a]">Bearbeitet von C. Bauer</div>
                </div>
                <div>
                  <div className="text-[#64748b]">24.05.2026, 09:15</div>
                  <div className="text-[#0f172a]">Zur Prüfung freigegeben</div>
                </div>
                <div>
                  <div className="text-[#64748b]">12.05.2026, 16:48</div>
                  <div className="text-[#0f172a]">Erstellt von M. Schmidt</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
