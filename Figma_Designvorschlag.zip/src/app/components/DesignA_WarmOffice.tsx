import { ChevronLeft, MoreVertical, Download, Filter } from 'lucide-react';

export default function DesignA_WarmOffice() {
  return (
    <div className="size-full bg-[#f5f3f0] overflow-auto">
      <div className="max-w-[1800px] mx-auto p-6">
        {/* Breadcrumb */}
        <button className="flex items-center gap-1.5 text-sm text-[#756b5e] hover:text-[#4a4035] mb-4 -ml-1">
          <ChevronLeft size={16} />
          Baustellen
        </button>

        {/* Project Header */}
        <div className="bg-white border border-[#e5e1db] shadow-sm mb-4">
          <div className="px-5 py-4 border-b border-[#e5e1db]">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[10px] font-semibold text-[#9e8f7c] uppercase tracking-wider mb-1">
                  Projektakte
                </div>
                <h1 className="text-xl font-semibold text-[#2d2620] mb-0.5">Schlüchtermann Klinik</h1>
                <div className="text-sm text-[#756b5e]">8007 - ebm</div>
              </div>
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 bg-[#d4edda] text-[#155724] text-xs font-medium border border-[#c3e6cb]">
                  Aktiv
                </span>
                <button className="p-1.5 hover:bg-[#f5f3f0] text-[#756b5e]">
                  <MoreVertical size={18} />
                </button>
              </div>
            </div>
          </div>

          {/* Main Tabs */}
          <div className="px-5 border-b border-[#e5e1db] bg-[#faf9f7]">
            <div className="flex gap-1 -mb-px">
              {['Übersicht', 'Ordnerstruktur', 'Montagezeiten', 'Aufmaß', 'Werkzeuge & Material'].map((tab, i) => (
                <button
                  key={tab}
                  className={`px-4 py-2.5 text-sm font-medium border-b-2 ${
                    i === 3
                      ? 'border-[#c17a3a] text-[#2d2620] bg-white'
                      : 'border-transparent text-[#756b5e] hover:text-[#4a4035] hover:bg-[#f5f3f0]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Content Card */}
        <div className="bg-white border border-[#e5e1db] shadow-sm">
          {/* Sub Tabs */}
          <div className="px-5 py-3 border-b border-[#e5e1db] bg-[#faf9f7]">
            <div className="flex gap-1.5">
              {['Zeitenliste', 'Prüfung', 'Zeitauswertung'].map((tab, i) => (
                <button
                  key={tab}
                  className={`px-3 py-1.5 text-sm font-medium ${
                    i === 0
                      ? 'bg-[#4a4035] text-white'
                      : 'bg-[#e5e1db] text-[#4a4035] hover:bg-[#d5d0c8]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Toolbar */}
          <div className="px-5 py-2.5 border-b border-[#e5e1db] bg-[#fdfcfb] flex items-center justify-between">
            <button className="px-3 py-1.5 text-sm text-[#4a4035] hover:bg-[#f5f3f0] font-medium">
              Zurück
            </button>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 border-r border-[#e5e1db] pr-2 mr-1">
                <button className="px-2.5 py-1.5 text-xs text-[#4a4035] hover:bg-[#f5f3f0] font-medium">
                  Liste
                </button>
                <button className="px-2.5 py-1.5 text-xs text-[#4a4035] hover:bg-[#f5f3f0] font-medium">
                  Tabelle
                </button>
              </div>
              <button className="px-2.5 py-1.5 text-xs bg-[#fff3cd] text-[#856404] border border-[#ffeaa7] hover:bg-[#ffe8a1] font-medium">
                Noch offen
              </button>
              <button className="px-2.5 py-1.5 text-xs text-[#4a4035] hover:bg-[#f5f3f0] font-medium">
                Undo
              </button>
              <button className="px-2.5 py-1.5 text-xs text-[#4a4035] hover:bg-[#f5f3f0] font-medium">
                Auf Monteurstand zurücksetzen
              </button>
              <div className="w-px h-4 bg-[#e5e1db] mx-1"></div>
              <button className="p-1.5 hover:bg-[#f5f3f0] text-[#756b5e]">
                <Filter size={14} />
              </button>
              <button className="p-1.5 hover:bg-[#f5f3f0] text-[#756b5e]">
                <Download size={14} />
              </button>
              <button className="px-3 py-1.5 text-xs bg-[#4a4035] text-white hover:bg-[#2d2620] font-medium ml-1">
                Als abgerechnet markieren
              </button>
            </div>
          </div>

          {/* Table Header */}
          <div className="px-5 py-2.5 border-b border-[#e5e1db] bg-[#faf9f7]">
            <h2 className="text-sm font-semibold text-[#2d2620]">Aufmaß 8007.05</h2>
          </div>

          {/* Excel-Style Table */}
          <div className="overflow-auto" style={{ maxHeight: 'calc(100vh - 400px)' }}>
            <table className="border-collapse" style={{ fontVariantNumeric: 'tabular-nums' }}>
              <thead className="sticky top-0 z-10">
                {/* Header Row 1: Position Numbers */}
                <tr>
                  <th className="bg-[#e5dfd5] border border-[#c9b89a] text-[10px] font-semibold text-[#4a4035] text-left px-2 py-1 min-w-[100px] sticky left-0 z-20">
                    Pos.-Nr.
                  </th>
                  <th className="bg-[#e5dfd5] border border-[#c9b89a] text-[10px] font-semibold text-[#4a4035] text-left px-2 py-1 min-w-[200px] sticky left-[100px] z-20">
                    Beschreibung
                  </th>
                  <th className="bg-[#e5dfd5] border border-[#c9b89a] text-[10px] font-semibold text-[#4a4035] text-left px-2 py-1 w-[60px] sticky left-[300px] z-20">
                    Einheit
                  </th>
                  <th className="bg-[#e5dfd5] border border-[#c9b89a] text-[10px] font-semibold text-[#4a4035] text-left px-2 py-1 min-w-[160px] sticky left-[360px] z-20">
                    Bauteil / Ort
                  </th>
                  {['1.01.05.20', '1.01.05.120', '1.01.05.160', '1.01.05.220', '1.01.05.280', '1.01.05.310', '1.01.05.450'].map(col => (
                    <th key={col} className="bg-[#e5dfd5] border border-[#c9b89a] text-[10px] font-semibold text-[#4a4035] text-center px-1.5 py-1 w-[85px]">
                      {col}
                    </th>
                  ))}
                </tr>
                {/* Header Row 2: Article Descriptions */}
                <tr>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] sticky left-0 z-20"></td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] sticky left-[100px] z-20"></td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] sticky left-[300px] z-20"></td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] sticky left-[360px] z-20"></td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] text-[9px] text-[#756b5e] text-center px-1 py-0.5 leading-tight">
                    FS L060...V5<br />Snegleiter<br />300/60 mm
                  </td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] text-[9px] text-[#756b5e] text-center px-1 py-0.5 leading-tight">
                    vorgenahte<br />C-Profitschiene<br />nach Örtlichkeit
                  </td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] text-[9px] text-[#756b5e] text-center px-1 py-0.5 leading-tight">
                    90°Rinnenbogen<br />600/60 mm<br />EF
                  </td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] text-[9px] text-[#756b5e] text-center px-1 py-0.5 leading-tight">
                    Vertikalgelenk<br />600/60 mm<br />als Bogen
                  </td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] text-[9px] text-[#756b5e] text-center px-1 py-0.5 leading-tight">
                    UEB-Stiel<br />bis 600 mm<br />liefern
                  </td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] text-[9px] text-[#756b5e] text-center px-1 py-0.5 leading-tight">
                    UEB-Stiel<br />bis 600 mm<br />montieren
                  </td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] text-[9px] text-[#756b5e] text-center px-1 py-0.5 leading-tight">
                    Stelzausleger<br />200 mm<br />liefern
                  </td>
                </tr>
                {/* Header Row 3: Units */}
                <tr>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] sticky left-0 z-20"></td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] sticky left-[100px] z-20"></td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] sticky left-[300px] z-20"></td>
                  <td className="bg-[#faf9f7] border border-[#c9b89a] sticky left-[360px] z-20"></td>
                  {Array(7).fill('STCK').map((unit, i) => (
                    <td key={i} className="bg-[#faf9f7] border border-[#c9b89a] text-[10px] font-medium text-[#4a4035] text-center px-1.5 py-0.5">
                      {unit}
                    </td>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Data Row 1: EG */}
                <tr className="hover:bg-[#fdfcfb]">
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] px-2 py-1 sticky left-0 z-10">EG</td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[100px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[300px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[360px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] text-right px-2 py-1">30,00</td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] text-right px-2 py-1">5,00</td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] text-right px-2 py-1">5,00</td>
                </tr>
                {/* Data Row 2: 1. OG */}
                <tr className="hover:bg-[#fdfcfb]">
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] px-2 py-1 sticky left-0 z-10">1. OG</td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[100px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[300px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[360px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] text-right px-2 py-1">500,00</td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] text-right px-2 py-1">100,00</td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                </tr>
                {/* Data Row 3: UG, 1 Achse D - E */}
                <tr className="hover:bg-[#fdfcfb]">
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] px-2 py-1 sticky left-0 z-10">UG, 1 Achse D - E</td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[100px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[300px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[360px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] text-right px-2 py-1">1.000,00</td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                </tr>
                {/* Data Row 4: Dach */}
                <tr className="hover:bg-[#fdfcfb]">
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#756b5e] px-2 py-1 leading-tight sticky left-0 z-10">
                    Dach, schräge,<br />Sicht zum<br />Feuerwehrhaus
                  </td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[100px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[300px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] sticky left-[360px] z-10"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                  <td className="bg-white border border-[#d5d0c8] text-[11px] text-[#2d2620] text-right px-2 py-1">1,60</td>
                </tr>
                {/* Additional empty rows for scrolling demonstration */}
                {Array(15).fill(null).map((_, idx) => (
                  <tr key={`empty-${idx}`} className="hover:bg-[#fdfcfb]">
                    <td className="bg-white border border-[#d5d0c8] text-[11px] px-2 py-1 sticky left-0 z-10"></td>
                    <td className="bg-white border border-[#d5d0c8] sticky left-[100px] z-10"></td>
                    <td className="bg-white border border-[#d5d0c8] sticky left-[300px] z-10"></td>
                    <td className="bg-white border border-[#d5d0c8] sticky left-[360px] z-10"></td>
                    {Array(7).fill(null).map((_, i) => (
                      <td key={i} className="bg-white border border-[#d5d0c8] text-[11px] text-right px-2 py-1"></td>
                    ))}
                  </tr>
                ))}
                {/* Total Row */}
                <tr className="sticky bottom-0 z-10">
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] text-[11px] font-semibold text-[#2d2620] px-2 py-1 sticky left-0 z-20">
                    Gesamt
                  </td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] sticky left-[100px] z-20"></td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] sticky left-[300px] z-20"></td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] sticky left-[360px] z-20"></td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] text-[11px] font-semibold text-[#2d2620] text-right px-2 py-1">500,00</td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] text-[11px] font-semibold text-[#2d2620] text-right px-2 py-1">100,00</td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] text-[11px] font-semibold text-[#2d2620] text-right px-2 py-1">30,00</td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] text-[11px] font-semibold text-[#2d2620] text-right px-2 py-1">5,00</td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] text-[11px] font-semibold text-[#2d2620] text-right px-2 py-1">1.000,00</td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] text-[11px] font-semibold text-[#2d2620] text-right px-2 py-1">5,00</td>
                  <td className="bg-[#e5dfd5] border-2 border-[#c9b89a] text-[11px] font-semibold text-[#2d2620] text-right px-2 py-1">1,60</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
